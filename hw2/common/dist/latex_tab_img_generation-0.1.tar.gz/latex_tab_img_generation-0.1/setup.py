from setuptools import setup, find_packages

setup(
    name="latex_tab_img_generation",
    version="0.1",
    packages=find_packages(),
    description="A library to generate LaTeX format tables and images",
    author="nikiandr",
    author_email="nikiandr@example.com",
    license="MIT",
    install_requires=[],
    zip_safe=False
)